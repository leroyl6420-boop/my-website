# Leroy's Portfolio
- I like to CAD
- I enjoy 3D printing
- I love microcontrollers
